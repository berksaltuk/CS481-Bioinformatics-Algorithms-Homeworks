Full Name: Berk Saltuk Yılmaz
Bilkent ID: 21903419
Email: saltuk.yilmaz@ug.bilkent.edu.tr
Course Name & Assignment #: CS481 HW0

Instructions:

First run `make` to compile all files.

To run example programs with inputs: 

	-n 3 -s 5
	-n 4 -s -3
	-n 5 -s 10
	-n 6 -s 2

run `make run` command.

To clean up, run `make clean` command.

To try the program with custom inputs, please run it in the form of: ./hw0 -n 3 -s 10

